BWP - Backup WiFi Password by Mo00ot.

This script can export/inport all WIFI Profiles and Password.

Use it with administation right.
Only Password pre-stored in the pc can be stolen.
This script crash if SSID have space in the name. 
	Use command All to avoid this problem.
For restore password previous exported use command Inport.

__How to use:

_to export 1 network:
-open it
-copy SSID or name of your network and paste it then press enter.
	a file named yourSSID-password.txt will created.

_to export all network:
-open it
-type all and press enter.
	this command create .xml files with name and in it the passowrd. 
	on line 22 <keyMaterial>here is your password</keyMaterial>

_to inport all network:    <place all .xml in the same directory of the script.>
-open it
-type inport and press enter.
	now will import all .xml in the same directory of the script.